RoJoiner Companion 0.2.0 — Firefox test build

1. Open about:debugging#/runtime/this-firefox
2. Click "Load Temporary Add-on"
3. Select this ZIP file
4. Sign in at roblox.com
5. Open RoJoiner Companion from the Firefox toolbar

This unsigned build is for transparent source testing. Standard Firefox requires Mozilla signing for permanent installation.

The extension requests access only to Roblox API domains, does not request the cookies permission, and does not transmit user data to RoJoiner.
